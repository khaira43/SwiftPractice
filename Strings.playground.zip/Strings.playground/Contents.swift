import Cocoa

let actor = "Denzel Washington"
let fileName = "paris.jpg"
let result = "blah🤣🤣"
let quote = "Then he tapped a sign saying \"Believe\" and walked away."
let movie = """
A day in
the life of an
Apple engineer
"""
let nameLength = actor.count
print(nameLength)
print(result.uppercased())//if swift has to read data then no brackets, if it has to do work then brakcets for now.
print(movie.hasPrefix("A day"))
print(fileName.hasSuffix(".jpg"))
