import Cocoa //import from Apple, always needed pretty much

var greeting = "Hello, playground" //semi colon is allowed but not needed, only required if two lines of code on same line needed.
greeting = "Ranbir"
let character = "Daphne" //this cannot change, unlike var

var playerName = "Roy"
print(playerName)//camelcase coding convention

playerName = "Dani"
print(playerName)

let managerName = "Michael Scott"
let dogBreed = "Samoyed"
let meaningOfLife = "Blah"
// constants r better than variables.


